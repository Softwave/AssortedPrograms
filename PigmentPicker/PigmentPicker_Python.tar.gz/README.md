A teeny tiny utility for picking colours from the display.

Licensed under the GNU General Public License, per the requirments of PyQt. 

## Icons Credit 

The icon comes from the Fugue Icons pack by [Yusuke Kamiyamane](https://p.yusukekamiyamane.com/). I think I'll be using them more in the future! Very wonderful. [CC BY 3.0 License](https://creativecommons.org/licenses/by/3.0/)
