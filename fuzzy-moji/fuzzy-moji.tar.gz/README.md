# FuzzyMoji

Simple fuzzy-finding emoji program written for my own use. Licensed under the GNU GPL version 3, as required by PyQt. See the LICENSE file. 

## Credit

Icon from the Open Emoji Set. 

https://openmoji.org/

Creative Commons Attribution 4.0 International

Font used for emojis is NotoColorEmoji. 

SIL OPEN FONT LICENSE Version 1.1
